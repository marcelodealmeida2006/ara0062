<?php
session_start();

$login = $_POST['login'];
$senha= $_POST['senha'];
$html=null;
//    echo "-->$login<-- -->$senha<--"; die();
if ($login=='admin' && $senha=='1234') {

   $_SESSION["autenticacao"]=true;

    echo '
      <script>
        window.location.replace("http://intelectoidiomas.com.br/ara0062/menu.php");
        </script>
    ';
    
}else {
    session_unset ( ) ;
    
    $html="
     <html>
      <head><title>Teste de PHP</title></head>
      <body>
           <h1> Não identificamos seu login e senha </h2>
           
           <p>Login= $login </p>
           <p>Senha= $senha </p>
      </body>
      </html>
    ";
    
}
    
echo $html ;

?>